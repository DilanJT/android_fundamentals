package com.example.tutorial_08;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DynamicLayouts extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dynamic_layouts);
    }
}