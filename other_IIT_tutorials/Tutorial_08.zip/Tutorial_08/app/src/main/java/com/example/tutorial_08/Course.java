package com.example.tutorial_08;

public class Course {
    public String name;
    public boolean isSaved;

    public Course(String name, boolean isSaved) {
        this.name = name;
        this.isSaved = isSaved;
    }
}
